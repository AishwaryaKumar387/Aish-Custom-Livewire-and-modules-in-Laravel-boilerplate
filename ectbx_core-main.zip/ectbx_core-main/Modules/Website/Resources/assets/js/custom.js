$(document).ready(function(){
	  // DataTable
	  $('.table').DataTable({
		  "language": {
            "lengthMenu": "Per Page: _MENU_",
            "zeroRecords": "Nothing found - sorry",
            "info": "Showing page _PAGE_ of _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtered from _MAX_ total records)"
        },
		 //processing: true,
		 serverSide: true,
		 ajax: "{{route('Website.gettables')}}",
		 columns: [
			{ data: 'id' },
			{ data: 'name' },
			{ data: 'created_at' },
			{ data: 'updated_at' },
		 ]
		 
	  });
	});