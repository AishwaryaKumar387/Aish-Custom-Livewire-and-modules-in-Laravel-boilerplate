@inject('model', '\Modules\Website\Entities\Website')

@extends('backend.layouts.app')

@section('title', __('Create Website'))

@section('content')

<x-forms.post :action="route('Website.store')" onkeydown="return event.key != 'Enter';">
        <x-backend.card>
            <x-slot name="header">
                @lang('Create Website')
            </x-slot>

            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
            
            <x-slot name="headerActions">
                <x-utils.link class="card-header-action" :href="route('Website')" :text="__('Cancel')" />
            </x-slot>

            <x-slot name="body">
                <div>
                    <div class="form-group row">
                        <label for="name" class="col-md-2 col-form-label">@lang('Website Name')</label>

                        <div class="col-md-10">
                            <input type="text" name="name" class="form-control" placeholder="{{ __('Name') }}" value="{{ old('name') }}" maxlength="100" required />
							<input id="submittype" type="hidden" name="submit_type" value=""></input>
                        </div>
                    </div><!--form-group-->
                </div>
            </x-slot>

            <x-slot name="footer">
			<div class="text-right">
                <button class="btn btn-sm btn-primary" onclick="saveandexit()" type="submit">@lang('save &amp; exit')</button>
				<button class="btn btn-sm btn-primary" onclick="save()" type="submit">@lang('save')</button>
			<div>	
            </x-slot>
        </x-backend.card>
    </x-forms.post>
	<script>
	function save() {
          document.getElementById("submittype").value = "save";
       }
	function saveandexit() {
		document.getElementById("submittype").value = "save-and-exit";
	}
	</script>
@endsection