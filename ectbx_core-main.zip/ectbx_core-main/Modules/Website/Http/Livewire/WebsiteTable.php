<?php

namespace Modules\Website\Http\Livewire;
use Modules\Website\Entities\Website;
use Livewire\WithPagination;
use Livewire\Component;

class WebsiteTable extends Component
{
	
    public function render()
    {
        return view('website::livewire.table');
    }
}