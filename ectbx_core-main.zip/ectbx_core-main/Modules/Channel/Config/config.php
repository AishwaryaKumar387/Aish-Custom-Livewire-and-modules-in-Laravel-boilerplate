<?php

return [
    'name' => 'Channel'
];
