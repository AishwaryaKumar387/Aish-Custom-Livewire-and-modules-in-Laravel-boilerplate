<?php

namespace Modules\Channel\Http\Livewire;
use Modules\Channel\Entities\Channel;
use Livewire\WithPagination;
use Livewire\Component;

class ChannelsTable extends Component
{
	
    public function render()
    {
		$channels = Channel::paginate(25);
        return view('channel::livewire.table')->with(compact('channels'));
    }
}