<?php

namespace Modules\Channel\Http\Controllers;
use Modules\Channel\Entities\Channel;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Foundation\Validation\ValidatesRequests;

class ChannelController extends Controller
{
    use ValidatesRequests;
    /**
     * Display a listing of the resource.
     * @return Renderable
     */

     /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
        $this->app->register(LivewireServiceProvider::class); // Add this line
    }

    public function index()
    {

        return view('channel::index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
  
        return view('channel::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
		//Save button clicked
		if($request->submit_type == "save")
		{
			$this->validate($request,[
            'name' => ['required', 'string', 'max:255','unique:channels'],
			]);
			$data = $request->all();
			$channel = Channel::create($data);
			return redirect()->route('Channel.edit', $channel->id)->withFlashSuccess(__('The channel was successfully added.'))->withInput();
		}
		//Save and exit button clicked
		else if($request->submit_type == "save-and-exit")
		{
			$this->validate($request,[
            'name' => ['required', 'string', 'max:255','unique:channels'],
			]);
			$data = $request->all();
			$channel = Channel::create($data);
			return redirect()->route('Channel')->withFlashSuccess(__('The channel was successfully added.'));
		}
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $channel = Channel::findOrFail($id);
        return view('channel::show')->with(compact('channel'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $channel = Channel::findOrFail($id);
        return view('channel::edit')->with(compact('channel'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //Save button clicked
		if($request->submit_type == "save")
		{
			$channel = Channel::findorfail($id);
			$this->validate($request,[
				'name' => ['required','unique:channels,name,'.$channel->id],
			]);

		    Channel::where('id','=', $id)->update([
				'name' => $request->name
			]);
			return redirect()->back()->withFlashSuccess(__('The channel was successfully updated.'));
		}
		//Save and exit button clicked
		else if($request->submit_type == "save-and-exit")
		{
			$channel = Channel::findorfail($id);
			$this->validate($request,[
				'name' => ['required','unique:channels,name,'.$channel->id],
			]);

		    Channel::where('id','=', $id)->update([
				'name' => $request->name
			]);
            return redirect()->route('Channel')->withFlashSuccess(__('The channel was successfully updated.'));
		}
		
       
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $channel = Channel::findOrFail($id);
        $channel->delete();
        return redirect()->back()->withFlashSuccess(__('The channel was successfully deleted.'));
    }
	
	/**
     * Clone the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
	 
	public function clone($id)
	{
		$channel = Channel::findOrFail($id);
		$new_channel = $channel->replicate();
		$new_channel->name = $channel->name.''."[copy]";
		$new_channel->save();
		return redirect()->back()->withFlashSuccess(__('The channel was successfully cloned.')); 
	}
	
	/**
     * custom data-table functionality
     */
	public function getChannel(Request $request)
    {
        $draw = $request->get('draw');
        $start = $request->get("start");
        $rowperpage = $request->get("length"); // Rows display per page

        $columnIndex_arr = $request->get('order');
        $columnName_arr = $request->get('columns');
        $order_arr = $request->get('order');
        $search_arr = $request->get('search');

        $columnIndex = $columnIndex_arr[0]['column']; // Column index
        $columnName = $columnName_arr[$columnIndex]['data']; // Column name
        $columnSortOrder = $order_arr[0]['dir']; // asc or desc
        $searchValue = $search_arr['value']; // Search value

        // Total records
        $totalRecords = Channel::select('count(*) as allcount')->count();
        $totalRecordswithFilter = Channel::select('count(*) as allcount')->where('name', 'like', '%' .$searchValue . '%')->count();

        // Fetch records
        $records = Channel::orderBy($columnName,$columnSortOrder)
            ->where('channels.name', 'like', '%' .$searchValue . '%')
            ->select('channels.*')
            ->skip($start)
            ->take($rowperpage)
            ->get();
			
        $data_arr = array();
		$sno = $start+1;
        foreach($records as $record){
            $id = $record->id;
            $name = $record->name;
            $created_at = date("jS F, Y H:i A", strtotime($record->created_at));
			$updated_at = date("jS F, Y H:i A", strtotime($record->created_at));
			$btn = '<a href="'.route('Channel.show', $id).'" class="btn btn-info btn-sm mr-1"><i class="fas fa-search"></i>View</a>';
            $btn = $btn.'<a href="'.route('Channel.edit', $id).'" class="btn btn-primary btn-sm"><i class="fas fa-pencil-alt"></i>Edit</a>';
            $btn = $btn.'<form method="POST" action="'.route('Channel.destroy', $id).'" name="delete-item" class="d-inline">
							<input type="hidden" name="_token" value="'.csrf_token().'">
							<input type="hidden" name="_method" value="delete">
							<button type="submit" class="btn btn-danger btn-sm">
								<i class="fas fa-trash"></i> Delete
							</button>
						</form>';
			$btn = $btn.'<a href="'.route('Channel.clone', $id).'" class="btn btn-primary btn-sm"><i class="fas fa-clone"></i>Clone</a>';
            
                       
                    
            $data_arr[] = array(
                "id" => $id,
                "name" => $name,
                "created_at" => $created_at,
                "updated_at" => $updated_at,
				"action" => $btn,
            );
        }
		
		

        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordswithFilter,
            "aaData" => $data_arr
        ); 

        echo json_encode($response);
        exit;
    }
}
