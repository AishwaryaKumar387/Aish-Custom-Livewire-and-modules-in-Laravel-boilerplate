<div>
    <div class="table-responsive">
        <table class="table table-striped" >
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Created On</th>
                    <th scope="col">Updated On</th>
					<th scope="col">Actions</th>
                </tr>
            </thead>
         </table>
    </div>
</div>


