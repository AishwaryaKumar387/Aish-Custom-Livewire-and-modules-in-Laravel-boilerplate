@inject('model', '\Modules\Channel\Entities\Channel')

@extends('backend.layouts.app')

@section('title', __('Update Channel'))

@section('content')
    <x-forms.patch :action="route('Channel.update', $channel->id)" onkeydown="return event.key != 'Enter';">
        <x-backend.card>
            <x-slot name="header">
                @lang('Update Channel')
            </x-slot>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
            <x-slot name="headerActions">
                <x-utils.link class="card-header-action" :href="route('Channel')" :text="__('Cancel')" />
            </x-slot>

            <x-slot name="body">
                <div>
                    <div class="form-group row">
                        <label for="name" class="col-md-2 col-form-label">@lang('Channel Name')</label>

                        <div class="col-md-10">
                            <input type="text"  name="name" class="form-control" placeholder="{{ __('Channel Name') }}" value="{{ old('name') ?? $channel->name }}" maxlength="100" required />
							<input id="submittype" type="hidden" name="submit_type" value=""></input>
                        </div>
                    </div><!--form-group-->
                    <div class="form-group row">
                    <small class="float-right text-muted">
                    <strong style="margin-left: 15px;">@lang('Channel Created On'):</strong> {{date("jS F , Y H:i A", strtotime($channel->created_at))}}
                    <br>
                    <strong style="margin-left: 15px;">@lang('Last updated On'):</strong> {{date("jS F , Y H:i A", strtotime($channel->updated_at))}}
                    <small>
                    </div>
                </div>
            </x-slot>

            <x-slot name="footer">
            <div class="text-right">
                <button class="btn btn-sm btn-primary" onclick="saveandexit()" type="submit">@lang('save &amp; exit')</button>
				<button class="btn btn-sm btn-primary" onclick="save()" type="submit">@lang('save')</button>
			<div>
            </x-slot>
            
        </x-backend.card>
    </x-forms.patch>
	<script>
	function save() {
          document.getElementById("submittype").value = "save";
       }
	function saveandexit() {
		document.getElementById("submittype").value = "save-and-exit";
	}
	</script>
@endsection
