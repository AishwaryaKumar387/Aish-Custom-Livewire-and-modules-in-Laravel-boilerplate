@extends('backend.layouts.app')

@section('title', __('Create Channel'))

@section('content')
<x-backend.card>
        <x-slot name="header">
            @lang('Channel Management')
        </x-slot>

        @if ($logged_in_user->hasAllAccess())
            <x-slot name="headerActions">
                <x-utils.link
                    icon="c-icon cil-plus"
                    class="card-header-action"
                    :href="route('Channel.create')"
                    :text="__('Create Channel')"
                />
            </x-slot>
        @endif

        <x-slot name="body">
            <livewire:channel::channels-table/>
        </x-slot>
    </x-backend.card>
@endsection

@section('custom-scripts')
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>	  
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script type="text/javascript">
	$(document).ready(function(){
	  // DataTable
	  $('.table').DataTable({
		  "language": {
            "lengthMenu": "Per Page: _MENU_",
            "zeroRecords": "Nothing found - sorry",
            "info": "Showing _START_ to _END_ out of _TOTAL_ results",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtered from _MAX_ total records)",
			"search": ""
        },
		'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': [-1] /* 1st one, start by the right */
		}],
		 //processing: true,
		 paging: true,
		 serverSide: true,
		 ajax: "{{route('Channel.gettables')}}",
		 columns: [
			{ data: 'id' },
			{ data: 'name' },
			{ data: 'created_at' },
			{ data: 'updated_at' },
			{ data: 'action' },
			
		 ]
		 
	  });
	  $('.dataTables_filter input').addClass('custom form-control');
	  $(".dataTables_filter input").attr("placeholder", "search");
	  $('#DataTables_Table_0_filter').css({"width":"60%"});
	  $('#DataTables_Table_0_filter label').css({"display":"block"});
	  $('#DataTables_Table_0_filter label input').css({"width":"98%"});
	  //$('.dataTables_paginate').hide();
	  $('.dataTables_info').css({"float":"right"})
	});
</script>
@endsection
