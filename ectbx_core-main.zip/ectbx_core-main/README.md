# ectbx_core

1. First use nwidart module:
    To install through Composer, by run the following command:
      Step 1: composer require nwidart/laravel-modules
    The package will automatically register a service provider and alias.
	Optionally, publish the package's configuration file by running:
	  Step 2: php artisan vendor:publish --provider="Nwidart\Modules\LaravelModulesServiceProvider"
	
	After this, it will autoload in composer.json like this:
		{
		  "autoload": {
		"psr-4": {
		  "App\\": "app/",
		  "Modules\\": "Modules/"
		}
			  }
		}
	But, unfortunately if it doesn't happen, you can add above manually.
	  Step 3: run composer dump-autoload afterwards (don't forget it)

2. Creating a module :
    Creating a module is simple and straightforward. Run the following command to create a module.
	 1. php artisan module:make <module-name>
	 Replace <module-name> by your desired name.
	 
	Note:By default when you create a new module, the command will add some resources like a controller, seed class, service provider, etc. automatically. 
	 If you don't want these, you can add --plain flag, to generate a plain module.
	 
3. Go in Routes/web.php in <module-name> folder :
   add on index action like :
   Route::get('/', '<module-name> Controller@index')->name('<module-name>');
   
   We are doing it like this because it will help in us getting menus in sidebar function , that will be created as a global function.
   
4. In app create a menuhelpers.php file:
		<?php
		use Nwidart\Modules\Facades\Module;
		if (! function_exists('menu_modules')) {
			/**
			 * Helper to grab the application name.
			 *
			 * @return mixed
			 */
			function menu_modules()
			{
				$menu = Module::all();
				/**
				 * Module::all() return all modules name.
				 *
				 * @return mixed
				*/
				return $menu;
			}
		?>
				
To declare it as a global function add in composer.json:
    autoload-dev": {
        "psr-4": {
            "Tests\\": "tests/"
        },
        "files":[
             "app/menuhelpers.php"
        ]
			},
		}
	After it run composer dump-autoload. 
	Now it will work as global function. In sidebar or else where in blade you want to use it , just write lines:
        @php 
        $menu = menu_modules(); <!-- it will call the function -->
        @endphp
		
		Now, Nwidart\Modules\Facades\Module provides us a function getName(),that returns modules name.
		That's why we used module name as route name and therefore we will use it in href or anchor tag.
		Example:
		@foreach($menu as $m)
          <li class="c-sidebar-nav-item">
            <x-utils.link
                class="c-sidebar-nav-link"
                :href="route($m->getName())" <!-- it will call the modules and will hit the index action of modules -->
                :active="activeClass(Route::is($m->getName().'*'), 'c-active')"
                icon="c-sidebar-nav-icon cil-tv"
                :text="__($m->getName())"  />
        </li>
        @endforeach
	Finally , run php artisan config:cache and php artisan route:list
Note:Custom Livewire components has been created and it can be use as <livewire:<Module-Name>::<Livewire Class>/>